#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D ImageSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 ImageSize;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec2 uv = gl_FragCoord.xy / OutSize;
    // PNG data origin: flip Y for the common OpenGL screen coordinate convention.
    uv.y = 1.0 - uv.y;
    // Aspect fill (cover): crop excess sides rather than leaving empty bars.
    float viewAspect = OutSize.x / max(OutSize.y, 1.0);
    float imageAspect = ImageSize.x / max(ImageSize.y, 1.0);
    if (viewAspect < imageAspect) {
        uv.x = (uv.x - 0.5) * (viewAspect / imageAspect) + 0.5;
    } else {
        uv.y = (uv.y - 0.5) * (imageAspect / viewAspect) + 0.5;
    }
    fragColor = vec4(texture(ImageSampler, uv).rgb, 1.0);
}
