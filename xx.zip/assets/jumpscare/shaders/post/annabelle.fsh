#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D ImageSampler;
layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 ImageSize;
};

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

// Fill the screen while keeping the PNG aspect ratio.
// Some outer edges are cropped on monitors that aren't 987:459.
void main() {
    vec2 uv = vec2(texCoord.x, 1.0 - texCoord.y);
    float displayRatio = OutSize.x / OutSize.y;
    float imageRatio = ImageSize.x / ImageSize.y;

    if (displayRatio < imageRatio) {
        uv.x = (uv.x - 0.5) * (displayRatio / imageRatio) + 0.5;
    } else {
        uv.y = (uv.y - 0.5) * (imageRatio / displayRatio) + 0.5;
    }

    fragColor = vec4(texture(ImageSampler, uv).rgb, 1.0);
}
