#version 330
#extension GL_ARB_separate_shader_objects : require

layout(location = 0) out vec2 texCoord;

// One full-screen triangle. Minecraft Java 26.3 uses gl_VertexIndex
// in the modern post-processing shader pipeline.
void main() {
    vec2 corner = vec2((gl_VertexIndex << 1) & 2, gl_VertexIndex & 2);
    gl_Position = vec4(corner * 2.0 - 1.0, 0.0, 1.0);
    texCoord = corner;
}
